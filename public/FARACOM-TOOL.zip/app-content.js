// FARACOM TOOL - Content Script for FARACOM Web Studio App
// Bridges messages from the Chrome Extension to the FARACOM React web app

(function() {
  window.sessionStorage.setItem("FARACOM_TOOL_INSTALLED", "true");
  window.postMessage({ type: "FARACOM_TOOL_STATUS", installed: true }, "*");

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "PING_FARACOM") {
      sendResponse({ status: "alive", title: document.title, url: window.location.href });
      return true;
    }

    if (request.action === "IMPORT_PRODUCT_DATA" || request.action === "FARACOM_IMPORT_DATA") {
      try {
        const detail = request.payload;
        window.dispatchEvent(new CustomEvent("FARACOM_IMPORT_PRODUCT", { detail }));
        window.postMessage({ type: "FARACOM_IMPORT_PRODUCT", payload: detail }, "*");
        
        sendResponse({ success: true, message: "FARACOM 웹앱으로 데이터 전달 완료" });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return true;
    }
  });
})();
